-- Breed counts by group
SELECT breed_group, COUNT(*) AS breed_count
FROM dogs
GROUP BY breed_group
ORDER BY breed_count DESC, breed_group ASC;

-- Reviewed breeds with high exercise needs
SELECT key, name, origin, breed_group, exercise_needs, energy
FROM reviewed_dogs
WHERE exercise_needs >= 4
ORDER BY exercise_needs DESC, energy DESC, name ASC
LIMIT 25;

-- Breeds with the widest lifespan range
SELECT
    key,
    name,
    min_life_expectancy,
    max_life_expectancy,
    (max_life_expectancy - min_life_expectancy) AS lifespan_span
FROM dogs
ORDER BY lifespan_span DESC, max_life_expectancy DESC, name ASC
LIMIT 25;

-- Breeds missing a reviewed source row
SELECT d.key, d.name, d.review_status
FROM dogs AS d
LEFT JOIN dog_sources AS s
    ON s.breed_key = d.key
WHERE s.breed_key IS NULL
ORDER BY d.name ASC;

-- Image inventory coverage per breed
SELECT
    d.key,
    d.name,
    COUNT(i.image_path) AS image_count,
    MAX(i.is_primary) AS has_primary_image
FROM dogs AS d
LEFT JOIN dog_images AS i
    ON i.breed_key = d.key
GROUP BY d.key, d.name
ORDER BY image_count DESC, d.name ASC
LIMIT 25;
