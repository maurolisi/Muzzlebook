# 628 Dog Breeds: Traits and Provenance

Curated breed profiles in CSV and SQLite with source tracking.

Snapshot date: 2026-04-24

## Why this dataset is worth publishing

- 628 breed rows in one flat, queryable table.
- 617 breeds already marked `reviewed` with a normalized primary source.
- CSV plus SQLite delivery, so it works for pandas, DuckDB, SQLite, Spark, and basic spreadsheet users.
- Explicit source inventory and image inventory tables, instead of a mystery one-file dump.

## Included files

| File | What it contains |
| --- | --- |
| `dog_breeds.csv` | Canonical breed-level dataset with traits, sizes, lifespan, text summary, review state, and primary source fields. |
| `dog_breed_sources.csv` | One-to-many normalized provenance rows for reviewed sources. |
| `dog_breed_images_inventory.csv` | Local image inventory metadata for each breed. |
| `dog_breeds.sqlite` | Query-ready SQLite database with `dogs`, `dog_sources`, `dog_images`, `dataset_meta`, and `reviewed_dogs`. |
| `data_dictionary.csv` | Column-level dictionary for the CSV exports. |
| `dataset_summary.json` | Snapshot-level counts and quick summary stats. |
| `sample_queries.sql` | Starter SQL queries for exploration. |

## Important caveat about images

The source project has local image assets for these breeds, but the binary image files are intentionally **not** included in this Kaggle package.

Reason: the current image inventory has path coverage, but almost no normalized public license metadata yet. Publishing the image binaries now would be sloppy. The export keeps the image inventory table so you can still join breeds to the project’s local asset map without redistributing files with unclear rights.

## Suggested Kaggle use cases

- Breed clustering by temperament, size, and working role.
- Filter/ranking systems for breed recommendation apps.
- SQL exercises on normalized reference data with one-to-many provenance joins.
- Quick visualizations by origin, breed group, lifespan, or exercise needs.

## Snapshot stats

- Breed rows: 629
- Reviewed breeds: 618
- Seeded breeds: 11
- Source rows: 618
- Image inventory rows: 1258
- Image binaries included: no
